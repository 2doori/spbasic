package card.validator.server;

public class CardServerLauncher {	
	public static void main(String[] args) {
		
	}	
}