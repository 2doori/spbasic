package card.validator.client;

public class ValidatorLauncher {
	public static void main(String[] args) {
		
	}
}