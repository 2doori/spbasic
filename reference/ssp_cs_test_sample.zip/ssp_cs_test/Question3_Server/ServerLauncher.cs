﻿using System;
using System.Threading;

namespace Question3_Server
{
    class ServerLauncher
    {
        static void Main(string[] args)
        {

        }
    }
}
