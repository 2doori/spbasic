﻿using System;
using System.Threading;

namespace Question4_Server
{
    class ServerLauncher
    {
        static void Main(string[] args)
        {

        }
    }
}
